import java.io.*;
import java.net.*;
import java.util.Scanner;

public class client {
    public void setUpClient(int port) {
        try {
            // 和服务器创建连接
            Socket socket = new Socket("localhost",port);

            // 要发送给服务器的信息
            OutputStream os = socket.getOutputStream();
            PrintWriter pw = new PrintWriter(os);
            InputStream is = socket.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String info = null;
            if ((info = br.readLine()) != null) {
                System.out.println("我是客户端，服务器返回信息：" + info);
            }
            int dt=0;
            while(true) {
                String msg="";
                msg=Integer.toString(dt)+Character.toString((char)13);
                dt++;
                if (dt==10)
                {
                    msg="bye"+Character.toString((char)13);
                }
                Scanner msc=new Scanner(System.in);
                System.out.println("请输入命令");
                msg=msc.next()+Character.toString((char)13);
                byte[] data = msg.getBytes();
                os.write(data);
                os.flush();

                // 从服务器接收的信息

                info = null;
                if ((info = br.readLine()) != null) {
                    System.out.println("我是客户端，服务器返回信息：" + info);
                }
                if (dt==10)
                    break;
            }
            socket.shutdownOutput();

            br.close();
            is.close();
            os.close();
            pw.close();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public static void main(String[] args) {

        client cs = new client();

        cs.setUpClient(8088);

    }
}
