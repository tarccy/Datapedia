import java.util.ArrayList;
import java.util.List;

public class Data_Repository {
    private enum data_type {
        IMAGE,TEXT,TABLE;
    }
    private String data_format;
    private Historical_Version_Tree his_tree;
    private int repository_id;
    private List<Dataset> dataset_list;
    private int next_id;
    public Data_Repository(){
        next_id=1;
        Dataset tmp=new Dataset(next_id);
        next_id++;
        dataset_list.add(tmp);
    }
    public boolean check_data_type(){
        return true;   //continue
    }
    public List<Integer> view_historical_version_tree(){
        return new ArrayList<Integer>();
    }
    public void create_new_edition(Dataset m_dataset){
        dataset_list.add(m_dataset);
    }
}
