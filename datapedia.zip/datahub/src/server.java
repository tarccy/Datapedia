import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class server {

    public void setUpServer(int port) {
        try {
            ServerSocket server = new ServerSocket(port);

            System.out.println("服务器创建成功" + port);

            while (true) {

                Socket client = server.accept();

                System.out.println("正在有客户端访问" + client.getRemoteSocketAddress());

                processChat(client);

                System.out.println("客户端访问结束");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    private void processChat(Socket client) throws Exception {

        OutputStream out = client.getOutputStream();

        InputStream ins = client.getInputStream();

        String s = "你好，欢迎来到服务器javake\r\n";

        byte[] data = s.getBytes();

        out.write(data);

        out.flush();

        System.out.println("par");

        byte[] buf = new byte[1024];

        int len=ins.read(buf);

        //String inputS = readString(ins);

        System.out.println("pas");

        int in = 0;

        while (!(len==-1)) {

            System.out.println(" 客户端说" + new String(buf,0,len,"UTF-8"));

            s = "服务器收到" + new String(buf,0,len,"UTF-8") + "\r\n";
            int res=1;
            // 取得组成这个字符串的字节数组
            PrintWriter pw=new PrintWriter(out);
            pw.write("hhdauhai");
            pw.close();
            System.out.println("输出");

            out.flush();

            break;
            //len=ins.read(buf);
            //inputS = readString(ins);// 读取客户端的下一次输入

        }

        /*s = "你好，欢迎再来 \r\n";

        data = s.getBytes();

        out.write(data);

        out.flush();*/

        client.close();// 关闭与客户端的连接

    }

    private String readString(InputStream ins) throws Exception {

        StringBuffer stb = new StringBuffer();

        char c = 0;

        while (c != 13) {

            int i = ins.read();// 读取客户端发来的一个字节

            c = (char) i;// 将输入的字节转换为一个Char

            stb.append(c);// 将读取到的一个字符加到字符串缓冲区中

        }

        String inputS = stb.toString().trim();

        return inputS;

    }

    public static void main(String[] args) {

        server cs = new server();

        cs.setUpServer(8088);

    }

}
